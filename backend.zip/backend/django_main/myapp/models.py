from django.db import models
from django.contrib.postgres.indexes import GinIndex
from django.db.models import Index
from django.db.models.functions import Cast
from django.db.models import DateTimeField, TimeField

class User(models.Model):
    username = models.CharField(max_length=100, unique=True, db_index=True)
    password = models.CharField(max_length=300, null=False)
    email = models.EmailField(unique=True, null=False, db_index=True)
    created_at = models.DateTimeField(auto_now_add=True)
    nickname = models.CharField(max_length=100, null=True, blank=True)
    is_admin = models.BooleanField(default=False)
    is_active = models.BooleanField(default=True)
    bio = models.TextField(null=True, blank=True)
    avatar = models.CharField(max_length=500, null=True, blank=True)

    def __str__(self):
        return self.username


class Testlar(models.Model):
    # user = models.ForeignKey(User)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    nom = models.CharField(max_length=200)
    fan = models.CharField(max_length=200)
    tavsif = models.TextField()
    test_id = models.CharField(max_length=100, unique=True, db_index=True)
    test_code = models.CharField(max_length=300, unique=True, db_index=True)
    test_key = models.CharField(max_length=100, unique=True, db_index=True)
    ispublic = models.BooleanField(default=False)
    istime = models.BooleanField(default=False)
    time = models.IntegerField(null=True, blank=True)  # vaqtni minutlarda saqlaymiz
    created = models.DateTimeField(auto_now_add=True)


class Hashtag(models.Model):
    # test = models.ForeignKey(Testlar, on_delete=models.CASCADE)
    name = models.CharField(max_length=100, unique=True, db_index=True)
    class Meta:
        indexes = [
            GinIndex(
                fields=["name"],
                name="hashtag_name_trgm_idx",
                opclasses=["gin_trgm_ops"]
            )
        ]

class TestlarHashtag(models.Model):
    test = models.ForeignKey(Testlar, on_delete=models.CASCADE)
    hashtag = models.ForeignKey(Hashtag, on_delete=models.CASCADE)
    tag = models.BooleanField(default=False)

# class Alias(models.Model):
#     name = models.CharField(max_length=100, unique=True, db_index=True)

# class HashtagAlias(models.Model):
#     hashtag = models.ForeignKey(Hashtag, on_delete=models.CASCADE)
#     alias = models.ForeignKey(Alias, on_delete=models.CASCADE)


class Savollar(models.Model):
    test = models.ForeignKey(Testlar, on_delete=models.CASCADE)
    text = models.TextField(null=True)
    svg_json = models.TextField(null=True)



class Variantlar(models.Model):
    savol = models.ForeignKey(Savollar, on_delete=models.CASCADE)
    text = models.TextField(null=True)
    is_true=models.BooleanField(null=True)

class Natijalar(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    test = models.ForeignKey(Testlar, on_delete=models.CASCADE)
    sum_son = models.IntegerField(default=0)
    true_son = models.IntegerField(default=0)
    false_son = models.IntegerField(default=0)
    answer = models.JSONField(null=True)
    isfinish = models.BooleanField(default=False)
    # time_spent = Column(Integer, default=0)
    time_spent = models.IntegerField(default=0)
    start_time = models.DateTimeField(null=True, blank=True)
    created = models.DateTimeField(auto_now_add=True)

    class Meta:
        indexes = [
            models.Index(fields=['created'], name='natijalar_created_idx'),
            models.Index(fields=['user', 'test'], name='natijalar_user_test_idx'),
            models.Index(fields=['isfinish'], name='natijalar_isfinish_idx'),
        ]

    @classmethod
    def create_time_index(cls):
        from django.db import connection
        with connection.cursor() as cursor:
            cursor.execute("""
                CREATE INDEX IF NOT EXISTS natijalar_created_time_idx
                ON myapp_natijalar ((created::time));
            """)

# class NatijaAnswer(models.Models):
#     natija = models.ForeignKey(Natijalar, on_delete=models.CASCADE)

class Comment(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    test = models.ForeignKey(Testlar, on_delete=models.CASCADE, null=True)
    text = models.TextField(null=True)
    created = models.DateTimeField(auto_now_add=True)
    type = models.CharField(max_length=50, null=True)  # comment yoki reply
    parent_comment = models.ForeignKey('self', on_delete=models.CASCADE, null=True, blank=True)  # Agar reply bo'lsa, parent commentni saqlash uchun

class Aloqa(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True)
    name = models.CharField(max_length=200, null=True, blank=True)
    email = models.EmailField(max_length=200, null=True, blank=True)
    telegram = models.CharField(max_length=200, null=True, blank=True)
    subject = models.CharField(max_length=200)
    message = models.TextField()
    created = models.DateTimeField(auto_now_add=True)
    type = models.CharField(max_length=50, null=True)
    is_read = models.BooleanField(default=False)

class TestRoom(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    test = models.ForeignKey(Testlar, on_delete=models.CASCADE)
    nom = models.CharField(max_length=200)
    tavsif = models.TextField(null=True, blank=True)
    is_message = models.BooleanField(default=True)  # chat qismi ko'rinsinmi
    is_password = models.BooleanField(default=False)  # kodli/kodsiz
    password = models.CharField(max_length=100, null=True, blank=True)  # guruhga kirish uchun kod
    created = models.DateTimeField(auto_now_add=True)
    is_active = models.BooleanField(default=True)  # room aktivmi

    def __str__(self):
        return self.nom

class RoomMessage(models.Model):
    room = models.ForeignKey(TestRoom, on_delete=models.CASCADE)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    text = models.TextField(null=False)
    created = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.room.nom} - {self.user.username}"