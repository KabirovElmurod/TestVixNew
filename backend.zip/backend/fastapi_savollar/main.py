from xml.etree.ElementInclude import include

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from .app.api.savollar import router as savollar_router
from .app.api.admin_savollar import router as admin_savollar_router

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://127.0.0.1:5173", 'http://localhost:5173', "http://localhost"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
from .app.redis.redis import get_redis, create_index_public_test_redis, create_index_hashtag_redis

@app.on_event("startup")
async def startup_event():
    redis = await get_redis()
    await redis.flushdb()  
    await create_index_public_test_redis()
    await create_index_hashtag_redis()
app.include_router(savollar_router)
app.include_router(admin_savollar_router)

@app.get("/")
async def root():
    return {"message": "API ishlayapti"}